from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse

app = FastAPI()

# Маршрут для извлечения заголовков
@app.get("/headers")
async def get_headers(request: Request):
    user_agent = request.headers.get("User-Agent")
    accept_language = request.headers.get("Accept-Language")

    # Проверка наличия заголовков
    if not user_agent or not accept_language:
        raise HTTPException(status_code=400, detail="Missing required headers")


    return JSONResponse(content={
        "User-Agent": user_agent,
        "Accept-Language": accept_language
    })


