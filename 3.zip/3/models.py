from pydantic import BaseModel, EmailStr, conint
from typing import Optional

class UserCreate(BaseModel):
    name: str
    email: str
    age: int
    is_subscribed: bool

class Product(BaseModel):
    product_id: int
    name: str
    category: str
    price: float
