
from fastapi import FastAPI, HTTPException, Depends, Request, Response, Form

from pydantic import BaseModel
from uuid import uuid4

app = FastAPI()

fake_users_db = {
    "user123": {
        "username": "user123",
        "password": "password123",
        "full_name": "John Doe",
        "email": "johndoe@example.com",
    }
}

# Хранилище сессий
session_store = {}

# Модель пользователя
class User(BaseModel):
    username: str
    full_name: str
    email: str


# Маршрут для входа
@app.post("/login")
async def login(response: Response, username: str = Form(...), password: str = Form(...)):
    user = fake_users_db.get(username)
    if user is None or user["password"] != password:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # Генерация токена сессии
    session_token = str(uuid4())
    session_store[session_token] = user["username"]

    # Установка cookie с токеном сессии
    response.set_cookie(key="session_token", value=session_token, httponly=True, secure=True)
    return {"message": "Login successful"}


# Зависимость для проверки сессии
def get_current_user(request: Request):
    session_token = request.cookies.get("session_token")
    if not session_token or session_token not in session_store:
        raise HTTPException(status_code=401, detail="Unauthorized")

    username = session_store[session_token]
    user = fake_users_db.get(username)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")

    return User(username=username, full_name=user["full_name"], email=user["email"])


# Защищенный маршрут
@app.get("/user", response_model=User)
async def read_user(current_user: User = Depends(get_current_user)):
    return current_user