from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import Dict, List, Any
from models import User, Feedback

app = FastAPI()



@app.get("/", response_class=HTMLResponse)
async def read_root():
    with open("index.html", "r", encoding="utf-8") as file:
        html_content = file.read()
    return HTMLResponse(content=html_content)



class Numbers(BaseModel):
    num1: int
    num2: int

@app.post("/calculate")
async def calculate(numbers: Numbers):
    result = numbers.num1 + numbers.num2
    return {"result": result}



# Экземпляр пользователя
user = User(name="John Doe", age=25)

@app.get("/users")
async def get_user() -> User:
    return user

@app.post("/user")
async def create_user(user: User):
    is_adult = user.age >= 18
    response = user.dict()
    response.update({"is_adult": is_adult})
    return response


# Хранилище для отзывов
feedback_storage: List[Feedback] = []

@app.post("/feedback")
async def create_feedback(feedback: Feedback):
    feedback_storage.append(feedback)
    return {"message": f"Feedback received. Thank you, {feedback.name}!"}

@app.get("/feedbacks", response_model=List[Feedback])
async def get_feedbacks() -> List[Feedback]:
    return feedback_storage
